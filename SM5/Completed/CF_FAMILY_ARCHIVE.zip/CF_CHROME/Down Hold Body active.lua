local t = Def.Sprite {
	Texture=NOTESKIN:GetPath( '_Down', 'hold body active' );
};
return t;