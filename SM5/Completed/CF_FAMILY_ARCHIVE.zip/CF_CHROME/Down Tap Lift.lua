local t = Def.Model {
	Meshes=NOTESKIN:GetPath('_down','tap lift model');
	Materials=NOTESKIN:GetPath('_down','tap lift model');
	Bones=NOTESKIN:GetPath('_down','tap lift model');
};

return t;
