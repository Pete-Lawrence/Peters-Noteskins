local t = Def.Sprite {
	Texture=NOTESKIN:GetPath( '_Down', 'roll body active' );
};
return t;